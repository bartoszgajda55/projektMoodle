﻿<?php session_start(); ?>
<html>
<head></head>
<body>
<?php
// domyslne dane
if(!isset($_SESSION['uzytkownik']) && !isset($_SESSION['wyslano'])) $_SESSION['uzytkownik'] = "1";

// sprawdzamy, ktory uzytkownik ma byc
if (isset($_GET['wyslano']) && $_GET['wyslano']=="tak")
{
	// wcisnieto przycisk polacz
	// czyli musimy zmienic usera z 1 na 2 (z wyswietlania do dodawania)
	if (isset($_POST['polacz']) && $_POST['polacz']=="Polacz")
	{
		$_SESSION['uzytkownik'] = "2";
	}
	// wciśnietyo przycisk rozlacz - czyli zmieniamy na usera 1
	else if (isset($_POST['polacz']) && $_POST['polacz']=="Rozlacz")
	{
		$_SESSION['uzytkownik'] = "1";
	}	
		
}

// przełączenie użytkownika
	// jeśli user nr 1, to łączymy usera nr1
	if ($_SESSION['uzytkownik'] == "1")
	{
		$connection=@mysql_connect('localhost', 'user1', 'uss1')
		or die('Brak połączenia'.mysql_error());

		//połączenie z bazą
		$db=@mysql_select_db('firma', $connection)
		or die('Brak bazy danych'.mysql_error());

	}
	// jeśli user nr 2, to łączymy usera nr2
	else if ($_SESSION['uzytkownik'] == "2")
	{
		$connection=@mysql_connect('localhost', 'user2', 'uss2')
		or die('Brak połączenia'.mysql_error());

		//połączenie z bazą
		$db=@mysql_select_db('firma', $connection)
		or die('Brak bazy danych'.mysql_error());
	}

// Sprawdzenie bladów
	if (isset($_GET['blad']) && $_GET['blad']=="edycja")
	{
		echo '<h3>Nie masz prawa edytować</h3>';
	}
	else if (isset($_GET['blad']) && $_GET['blad']=="usun")
	{
		echo '<h3>Nie masz prawa usuwać</h3>';
	}


	// operacje na bazie
	
	// dodawanie  rekordu
	if (isset($_POST['zapisz']) && $_POST['zapisz']=="Zapisz" && $_SESSION['uzytkownik'] == "2")
	{
		// przypisanie zmiennych
		$b_Title = $_POST['Title'];
		$b_FName = $_POST['FName'];
		$b_LName = $_POST['LName'];
		$b_AddressLine = $_POST['AddressLine'];
		$b_Town = $_POST['Town'];
		$b_ZipCode= $_POST['ZipCode'];
		$b_Phone = $_POST['Phone'];
		
		$zapytanie = "INSERT INTO customer (`title`, `fname`, `lname`, `addressline`, `town`, `zipcode`, `phone`) 
						VALUES ('{$b_Title}', '{$b_FName}', '{$b_LName}', '{$b_AddressLine}', '{$b_Town}', '{$b_ZipCode}', '{$b_Phone}');";
		$idzapytania = mysql_query($zapytanie) or die ("Dodawanie do bazy się nie powidło");
		echo "<h3>Dodano poprawnie</h3>";
	}
	else if (isset($_POST['zapisz']) && $_POST['zapisz']=="Zapisz" && $_SESSION['uzytkownik'] == "1") echo "<h3>Nie masz prawa nic dodawac</h3>";
	

	// edycja rekordu
	if (isset($_GET['edytuj']) && $_GET['edytuj']=="tak" && $_SESSION['uzytkownik'] == "2")
	{
		// wyświetlamy formularze edycji
		if (isset($_GET['form']) && $_GET['form']=="tak")
		{
			// pobranie danych z bazy i wstawienie je do pol edycji
			$zapytanie = mysql_query("SELECT * FROM customer WHERE customer_id={$_GET['id']}");
			while($cc = mysql_fetch_array($zapytanie)) { 
				// pobranie danych
				$e_customer_id = $cc['customer_id'];
				$e_title = $cc['title'];
				$e_fname = $cc['fname'];
				$e_lname = $cc['lname'];
				$e_addressline = $cc['addressline']; 
				$e_town = $cc['town'];
				$e_zipcode = $cc['zipcode'];
				$e_phone = $cc['phone'];
			
			} 
			
				// wyswietlenie tabelki z aktualnie edytowanym rekordem
				echo "<table cellpadding=\"2\" border=1>"; 
				echo "<tr><td><b>ID</b></td><td><b>Title</td><td><b>FName</td><td><b>LName</td><td><b>AddressLine</td><td><b>Town</td><td><b>ZipCode</td><td><b>Phone</td></tr>";
				echo'<tr>
				<form action="index.php?form=nie&edytuj=tak&id='.$_GET['id'].'" method="post">
				<td><?=$e_customer_id?></td>
				<td><input type="text" name="Title" placeholder="Title" value="'.$e_title.'"></td>
				<td><input type="text" name="FName" placeholder="FName" value="'.$e_fname.'"></td>
				<td><input type="text" name="LName" placeholder="LName" value="'.$e_lname.'"></td>
				<td><input type="text" name="AddressLine" placeholder="AddressLine" value="'.$e_addressline.'"></td>
				<td><input type="text" name="Town" placeholder="Town" value="'.$e_town.'"></td>
				<td><input type="text" name="ZipCode" placeholder="ZipCode" value="'.$e_zipcode.'"></td>
				<td><input type="text" name="Phone" placeholder="Phone" value="'.$e_phone.'"></td>
				<td><input type="submit" name="zapisz" value="Zatwierdz zmiany"></td>
				</tr></table>
				</form> ';
				echo "</table>"; 
			
			
		return;	
		}
		// formularz z edycja przeslano, wstawiamy dane
		if (isset($_GET['form']) && $_GET['form']=="nie")
		{
			// przypisanie zmiennych
			$b_Title = $_POST['Title'];
			$b_FName = $_POST['FName'];
			$b_LName = $_POST['LName'];
			$b_AddressLine = $_POST['AddressLine'];
			$b_Town = $_POST['Town'];
			$b_ZipCode= $_POST['ZipCode'];
			$b_Phone = $_POST['Phone'];
			$idd = $_GET['id'];
			// aktualizacja danych
			$zapytanie = "UPDATE `customer` SET `title` = '{$b_Title}', `fname` = '{$b_FName}', `lname` = '{$b_LName}', `addressline` = '{$b_AddressLine}', `town` = '{$b_Town}', `zipcode` = '{$b_ZipCode}', `phone` = '{$b_Phone}' WHERE customer_id={$idd}";
			//echo $zapytanie;
			$idzapytania = mysql_query($zapytanie) or die ("Nie udalo sie edytowac");
			// przekierowanie do strony glownej, by wyczyscic $_POST
			header ("Location: index.php?komunikat=edit"); 
			
		}
		
	}
	// komunikat o powodzeniu
	if (isset($_GET['komunikat']) && $_GET['komunikat']=="edit") echo '<h3>Dane poprawnie wyedytowano</h3>';

	// usuwanie rekordu 
	if (isset($_GET['usun']) && $_GET['usun']=="tak" && $_SESSION['uzytkownik'] == "2")
	{
		$zapytanie = "DELETE FROM `customer` WHERE customer_id={$_GET['id']}";
		$idzapytania = mysql_query($zapytanie) or die("Nie da sie usunac");
		echo '<h3>Poprawnie usunięto</h3>';
	}

	
// ---------- wyswietlenie tabeli - punkt 1 ------------------------------------------
// zapytanie do konkretnej tabeli 
$wynik = mysql_query("SELECT * FROM customer") 
or die('Błąd zapytania'); 

/* 
wyświetlamy wyniki, sprawdzamy, czy zapytanie zwróciło wartość większą od 0 
*/ 

if(mysql_num_rows($wynik) > 0 && $_SESSION['uzytkownik'] == "1") { 
    /* jeżeli wynik jest pozytywny, to wyświetlamy dane */ 
    echo "<table cellpadding=\"2\" border=1>"; 
	// naglowek tabeli
	echo "<tr><td><b>ID</b></td><td><b>Title</td><td><b>FName</td><td><b>LName</td><td><b>Town</td></tr>";
    while($r = mysql_fetch_array($wynik)) { 
        echo "<tr>"; 
        echo "<td>{$r['customer_id']}</td>"; 
		echo "<td>{$r['title']}</td>"; 
		echo "<td>{$r['fname']}</td>"; 
		echo "<td>{$r['lname']}</td>"; 
		echo "<td>{$r['town']}</td>"; 
		echo "<td><a href='index.php?blad=edycja&id={$r['customer_id']}'>Edytuj</a></td>";
		echo "<td><a href='index.php?blad=usun&id={$r['customer_id']}'>Usuń</a></td>"; 

        /*echo "<td> 
       <a href=\"index.php?a=del&amp;id={$r[0]}\">DEL</a> 
       <a href=\"index.php?a=edit&amp;id={$r[0]}\">EDIT</a> 
       </td>"; */
        echo "</tr>"; 
    } 
	
	echo'<tr>
	<form action="index.php?wyslano=tak" method="post">
	<td><input type="text" name="" placeholder="ID"></td>
	<td><input type="text" name="" placeholder="Title"></td>
	<td><input type="text" name="" placeholder="FName"></td>
	<td><input type="text" name="" placeholder="LName"></td>
	<td><input type="text" name="" placeholder="Town"></td>
	<td><input type="submit" name="zapisz" value="Zapisz"></td>
	<td><input type="submit" name="polacz" value="Polacz"></td>
	</tr></table>
	</form> ';
	
    echo "</table>"; 
	
	
} 

// ----------------  punkt 2 --------------------------------------------------------------
// ---- po polaczeniu 
if(mysql_num_rows($wynik) > 0 && $_SESSION['uzytkownik'] == "2") { 
    /* jeżeli wynik jest pozytywny, to wyświetlamy dane */ 
    echo "<table cellpadding=\"2\" border=1>"; 
	// naglowek tabeli
	echo "<tr><td><b>ID</b></td><td><b>Title</td><td><b>FName</td><td><b>LName</td><td><b>AddressLine</td><td><b>Town</td><td><b>ZipCode</td><td><b>Phone</td></tr>";
    while($r = mysql_fetch_array($wynik)) { 
        echo "<tr>"; 
        echo "<td>{$r['customer_id']}</td>"; 
		echo "<td>{$r['title']}</td>"; 
		echo "<td>{$r['fname']}</td>"; 
		echo "<td>{$r['lname']}</td>"; 
		echo "<td>{$r['addressline']}</td>"; 
		echo "<td>{$r['town']}</td>"; 
		echo "<td>{$r['zipcode']}</td>";
		echo "<td>{$r['phone']}</td>";
		echo "<td><a href='index.php?form=tak&edytuj=tak&id={$r['customer_id']}'>Edytuj</a></td>";
		echo "<td><a href='index.php?usun=tak&id={$r['customer_id']}'>Usuń</a></td>"; 

        /*echo "<td> 
       <a href=\"index.php?a=del&amp;id={$r[0]}\">DEL</a> 
       <a href=\"index.php?a=edit&amp;id={$r[0]}\">EDIT</a> 
       </td>"; */
        echo "</tr>"; 
    } 
	
	echo'<tr>
	<form action="index.php?wyslano=tak" method="post">
	<td></td>
	<td><input type="text" name="Title" placeholder="Title"></td>
	<td><input type="text" name="FName" placeholder="FName"></td>
	<td><input type="text" name="LName" placeholder="LName"></td>
	<td><input type="text" name="AddressLine" placeholder="AddressLine"></td>
	<td><input type="text" name="Town" placeholder="Town"></td>
	<td><input type="text" name="ZipCode" placeholder="ZipCode"></td>
	<td><input type="text" name="Phone" placeholder="Phone"></td>
	<td><input type="submit" name="zapisz" value="Zapisz"></td>
	<td><input type="submit" name="polacz" value="Rozlacz"></td>
	</tr></table>
	</form> ';
	
    echo "</table>"; 
} 

?>
</body>
</head>