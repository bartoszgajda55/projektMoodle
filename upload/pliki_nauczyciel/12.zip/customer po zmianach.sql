-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Czas generowania: 31 Paź 2015, 23:38
-- Wersja serwera: 5.6.24
-- Wersja PHP: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Baza danych: `firma`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` int(11) NOT NULL,
  `title` char(4) DEFAULT NULL,
  `fname` varchar(32) DEFAULT NULL,
  `lname` varchar(32) NOT NULL,
  `addressline` varchar(64) DEFAULT NULL,
  `town` varchar(32) DEFAULT NULL,
  `zipcode` char(10) NOT NULL,
  `phone` varchar(16) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

--
-- Zrzut danych tabeli `customer`
--

INSERT INTO `customer` (`customer_id`, `title`, `fname`, `lname`, `addressline`, `town`, `zipcode`, `phone`) VALUES
(1, 'Miss', 'Jenny', 'Stones', '27 Rowan Avenue', 'Hightown', 'NT2 1AQ', '023 9876'),
(2, 'Mr', 'Andrew', 'Stones', '52 The Willows', 'Lowtown', 'LT5 7RA', '876 3527'),
(4, 'Mr', 'Adrian', 'Matthew', 'The Barn', 'Yuleville', 'YV67 2WR', '487 3871'),
(5, 'Pani', 'Wielki', 'Krol', '120', 'Palac', '00 0000', '00 000 0'),
(6, 'Mr', 'Neil', 'Matthew', '5 Pasture Lane', 'Nicetown', 'NT3 7RT', '267 1232'),
(7, 'Mr', 'Richard', 'Stones', '34 Holly Way', 'Bingham', 'BG4 2WE', '342 5982'),
(8, 'Mrs', 'Anna', 'Stones', '34 Holly Way', 'Bingham', 'BG4 2WE', '342 5982'),
(9, 'Mrs', 'Christine', 'Hickman', '36 Queen Street', 'Histon', 'HT3 5EM', '342 5432'),
(10, 'Mr', 'Mike', 'Howard', '86 Dysart Street', 'Tibsville', 'TB3 7FG', '505 5482'),
(11, 'Mr', 'Dave', 'Jones', '54 Vale Rise', 'Bingham', 'BG3 8GD', '342 8264'),
(12, 'Mr', 'Richard', 'Neill', '42 Thached way', 'Winersby', 'WB3 6GQ', '505 6482'),
(13, 'Mrs', 'Laura', 'Hendy', '73 Margeritta Way', 'Oxbridge', 'OX2 3HX', '821 2335'),
(14, 'Mr', 'Bill', 'Neill', '2 Beamer Street', 'Welltown', 'WT3 8GM', '435 1234'),
(15, 'Mr', 'David', 'Hudson', '4  The Square', 'Milltown', 'MT2 6RT', '961 4526'),
(30, 'Mrs', 'Bohdan', 'Zydek', '3 Plac slawy', 'Warsaw', 'ABC 32j', '1500 100'),
(31, 'Mr', 'Donald', 'Tramp', '1 Broadway Street', 'New York', 'ABC DEFG', '123 4567');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT dla tabeli `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
