﻿<?php session_start(); ?>
<?php

?>

<html>
<head></head>
<body>
<?php
// domyslne dane
if(!isset($_SESSION['uzytkownik']) && !isset($_SESSION['wyslano'])) $_SESSION['uzytkownik'] = "1";

// sprawdzamy, ktory uzytkownik ma byc
if (isset($_GET['wyslano']) && $_GET['wyslano']=="tak")
{
	// wcisnieto przycisk polacz
	// czyli musimy zmienic usera z 1 na 2 (z wyswietlania do dodawania)
	if (isset($_POST['polacz']) && $_POST['polacz']=="Polacz")
	{
		$_SESSION['uzytkownik'] = "2";
	}
	// wciśnietyo przycisk rozlacz - czyli zmieniamy na usera 1
	else if (isset($_POST['polacz']) && $_POST['polacz']=="Rozlacz")
	{
		$_SESSION['uzytkownik'] = "1";
	}	
		
}

// przełączenie użytkownika
	// jeśli user nr 1, to łączymy usera nr1
	if ($_SESSION['uzytkownik'] == "1")
	{
		$connection=@mysql_connect('localhost', 'user1', 'uss1')
		or die('Brak połączenia'.mysql_error());

		//połączenie z bazą
		$db=@mysql_select_db('firma', $connection)
		or die('Brak bazy danych'.mysql_error());

	}
	// jeśli user nr 2, to łączymy usera nr2
	else if ($_SESSION['uzytkownik'] == "2")
	{
		$connection=@mysql_connect('localhost', 'user2', 'uss2')
		or die('Brak połączenia'.mysql_error());

		//połączenie z bazą
		$db=@mysql_select_db('firma', $connection)
		or die('Brak bazy danych'.mysql_error());
	}

echo $_SESSION['uzytkownik'];

// ---------- wyswietlenie tabeli - punkt 1 ------------------------------------------
// zapytanie do konkretnej tabeli 
$wynik = mysql_query("SELECT * FROM customer") 
or die('Błąd zapytania'); 

/* 
wyświetlamy wyniki, sprawdzamy, czy zapytanie zwróciło wartość większą od 0 
*/ 

if(mysql_num_rows($wynik) > 0 && $_SESSION['uzytkownik'] == "1") { 
    /* jeżeli wynik jest pozytywny, to wyświetlamy dane */ 
    echo "<table cellpadding=\"2\" border=1>"; 
	// naglowek tabeli
	echo "<tr><td><b>ID</b></td><td><b>Title</td><td><b>FName</td><td><b>LName</td><td><b>Town</td></tr>";
    while($r = mysql_fetch_array($wynik)) { 
        echo "<tr>"; 
        echo "<td>{$r['customer_id']}</td>"; 
		echo "<td>{$r['title']}</td>"; 
		echo "<td>{$r['fname']}</td>"; 
		echo "<td>{$r['lname']}</td>"; 
		echo "<td>{$r['town']}</td>"; 

        /*echo "<td> 
       <a href=\"index.php?a=del&amp;id={$r[0]}\">DEL</a> 
       <a href=\"index.php?a=edit&amp;id={$r[0]}\">EDIT</a> 
       </td>"; */
        echo "</tr>"; 
    } 
	
	echo'<tr>
	<form action="index.php?wyslano=tak" method="post">
	<td><input type="text" name="" placeholder="ID"></td>
	<td><input type="text" name="" placeholder="Title"></td>
	<td><input type="text" name="" placeholder="FName"></td>
	<td><input type="text" name="" placeholder="LName"></td>
	<td><input type="text" name="" placeholder="Town"></td>
	<td><input type="submit" name="zapisz" value="Zapisz"></td>
	<td><input type="submit" name="polacz" value="Polacz"></td>
	</tr></table>
	</form> ';
	
    echo "</table>"; 
	
	
} 

// ----------------  punkt 2 --------------------------------------------------------------
// ---- po polaczeniu 
if(mysql_num_rows($wynik) > 0 && $_SESSION['uzytkownik'] == "2") { 
    /* jeżeli wynik jest pozytywny, to wyświetlamy dane */ 
    echo "<table cellpadding=\"2\" border=1>"; 
	// naglowek tabeli
	echo "<tr><td><b>IDsssssssss s s s</b></td><td><b>Title</td><td><b>FName</td><td><b>LName</td><td><b>Town</td></tr>";
    while($r = mysql_fetch_array($wynik)) { 
        echo "<tr>"; 
        echo "<td>{$r['customer_id']}</td>"; 
		echo "<td>{$r['title']}</td>"; 
		echo "<td>{$r['fname']}</td>"; 
		echo "<td>{$r['lname']}</td>"; 
		echo "<td>{$r['town']}</td>"; 

        /*echo "<td> 
       <a href=\"index.php?a=del&amp;id={$r[0]}\">DEL</a> 
       <a href=\"index.php?a=edit&amp;id={$r[0]}\">EDIT</a> 
       </td>"; */
        echo "</tr>"; 
    } 
	
	echo'<tr>
	<form action="index.php?wyslano=tak" method="post">
	<td><input type="text" name="" placeholder="ID"></td>
	<td><input type="text" name="" placeholder="Title"></td>
	<td><input type="text" name="" placeholder="FName"></td>
	<td><input type="text" name="" placeholder="LName"></td>
	<td><input type="text" name="" placeholder="Town"></td>
	<td><input type="submit" name="zapisz" value="Zapisz"></td>
	<td><input type="submit" name="polacz" value="Rozlacz"></td>
	</tr></table>
	</form> ';
	
    echo "</table>"; 
} 




?>

Po kliknięciu na przycisk połącz łączy użytkownika drugiego z bazą i wtedy istnieje możliwość 
zapisania nowego rekordu (wprowadza dane do bazy, usunięcia albo zmodyfikowania). Jeżeli nie jesteśmy połączeni 
jako użytkownik 2 to nie możemy zapisać danych do bazy (wyświetla się stosowny komunikat). 
Po nawiązaniu połączenia zmienia się napis na przycisku połącz na rozłącz oraz widzimy kolumny phone,  zipcode i addressline.



</body>
</head>